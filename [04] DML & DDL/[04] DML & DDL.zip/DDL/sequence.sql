--1단계

create sequence seqUser;
create sequence seqTourArea;
create sequence seqOfficer;
create sequence seqRecommend;
create sequence seqPlanner;


--2단계

create sequence seqTourPlan;
create sequence seqTourSpot;
create sequence seqParking;
create sequence seqRestaurant;
create sequence seqSafetyInfo;
create sequence seqFestival;
create sequence seqNewSpot;
create sequence seqControlTour;


--3단계

create sequence seqTourGoodsList;
create sequence seqSpotReview;
create sequence seqRestaurantReview;
create sequence seqMyTour;
create sequence seqTourDate;
create sequence seqTourPicture;
create sequence seqRestaurantPicture;
create sequence seqFestivalPicture;
create sequence seqSpotList;
create sequence seqControlPicture;
create sequence seqControlReservation;

--4단계

create sequence seqVisitSpot;
create sequence seqControlReview;



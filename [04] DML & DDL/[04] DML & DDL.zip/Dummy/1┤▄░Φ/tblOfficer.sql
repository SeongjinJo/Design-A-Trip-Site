insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'김아영','01082792563');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'이재호','01088888888');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'박재철','01082932222');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'최송이','01045282013');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'한아름','01022233334');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'김다정','01033375650');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'장은철','01099999999');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'김정우','01055555555');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'정소영','01044444444');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'백경은','01066667777');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'서현경','01024245656');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'이선형','01020998899');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'이영훈','01056789012');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'박소담','01066886688');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'변민우','01015411541');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'강인호','01068710101');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'양소희','01011002200');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'남지수','01033004455');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'박경호','01012112222');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'이현재','01085857878');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'김석훈','01023992499');
insert into tblOfficer (seq, name, tel) values (seqOfficer.nextVal,'조안나','01009098282');


select * from tblOfficer
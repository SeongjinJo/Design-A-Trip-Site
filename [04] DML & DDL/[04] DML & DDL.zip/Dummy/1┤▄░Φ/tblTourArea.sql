insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '용산구', '용산동2가'); --남산타워
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '세종로1-57'); --경복궁, 2번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '와룡동'); --창덕궁
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '중구', '정동5-1'); --덕수궁
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '훈정동1-2'); --종묘
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '와룡동2-1'); --창경궁
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '송파구', '신천동29'); --롯데타워
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '강남구', '삼성동159'); --코엑스
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '중구', '을지로7가'); -- DDP
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '부암동'); -- 북악산
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '세종로'); --1번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '송파구', '방이동'); --2번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '송파구', '석촌동'); --3번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '송파구', '잠실동'); --4번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '강남구', '삼성동159'); --5번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '영등포구', '양평동'); --6분축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '사직동'); --7번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '사직동1-28'); --8번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '종로구', '와룡동2-71'); --10번축제
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '영등포구', '문래동3가'); --1번 신규
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '중구', '을지로동'); --2번 신규
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '서초구', '방배동811-15'); --3번 신규
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '마포구', '증산로87'); --4번 신규
insert into tblTourArea (seq, state, city, town) values (seqTourArea.nextVal, '서울특별시', '송파구', '송파동'); --5번 신규

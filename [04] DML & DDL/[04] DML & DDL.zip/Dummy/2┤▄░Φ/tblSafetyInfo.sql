-- 안정정보 24장소
-- 남산타워
-- 대한민국 재난정보 사이트
-- 안전산행정보
-- 지역축제장 안전관리매뉴얼


INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 1, 'https://www.seoultower.co.kr/');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 2, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 3, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 4, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 5, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 6, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 7, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 8, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 9, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 10, 'https://fire.seoul.go.kr/pages/cnts.do?id=1707');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 11, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 12, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 13, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 14, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 15, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 16, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 17, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 18, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 19, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 20, 'https://www.korea.kr/archive/expDocView.do?docId=35048');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 21, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 22, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 23, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');
INSERT INTO tblSafetyInfo (seq, tourAreaSeq, safetyAddress) VALUES (seqSafetyInfo.nextval, 24, 'https://www.safekorea.go.kr/idsiSFK/neo/main/main.html');


--22.원격투어사진

insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,1,'con_01.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,2,'con_02.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,3,'con_03.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,4,'con_04.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,5,'con_05.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,6,'con_06.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,7,'con_07.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,8,'con_08.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,9,'con_09.jpg');
insert into tblControlPicture(seq, controlTourSeq, pictureAddress) values(seqControlPicture.nextVal,10,'con_10.jpg');
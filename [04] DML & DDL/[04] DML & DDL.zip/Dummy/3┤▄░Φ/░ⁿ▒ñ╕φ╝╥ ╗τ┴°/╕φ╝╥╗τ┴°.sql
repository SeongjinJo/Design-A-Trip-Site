--19. 명소사진

insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,1,'spot_01.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,2,'spot_02.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,3,'spot_03.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,4,'spot_04.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,5,'spot_05.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,6,'spot_06.pg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,7,'spot_07.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,8,'spot_08.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,9,'spot_09.jpg');
insert into tblTourPicture (seq, tourSpotSeq, pictureAddress) values (seqTourPicture.nextVal,10,'spot_10.jpg');